package com.example.mycabshare.Remote;


import retrofit2.Retrofit;

public class RetrofitClient {

    private static Retrofit instance;

    /*public static Retrofit getInstance(){
        return instance == null ? new Retrofit.Builder()
                .baseUrl("https://maps.googleapis.com/")
                .addConverterFactory();
    }*/
}

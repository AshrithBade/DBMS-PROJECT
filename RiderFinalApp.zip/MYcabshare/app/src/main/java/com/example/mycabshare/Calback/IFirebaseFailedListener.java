package com.example.mycabshare.Calback;

public interface IFirebaseFailedListener {

    void onFirebaseLoadFailed(String message);
}

package com.example.mycabshare;

public class User {

    public String num,token;

    public User(){

    }
    public User(String num,String token){

        this.num=num;
        this.token=token;
    }

}
